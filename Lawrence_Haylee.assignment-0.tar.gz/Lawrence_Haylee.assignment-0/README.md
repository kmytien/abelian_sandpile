## Project Simulating the Abelian Sandpile
- A C Project for CS327 Assignment 0
- This project models the Abelian Sandpile with the rules: 
  - if grains of sand are >= 8 topple
  - if grains of sand are < 8, stable
  - adding a sink will not let the grains around it accumulate like normal
- No extra challenges were coded in this project

### Project Group Members

- MyTien Kien (kmytien)
- Haylee Lawrence (hayleel)
- Sanjana Amatya (samatya)
